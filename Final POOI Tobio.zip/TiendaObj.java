import java.util.ArrayList;
import java.util.Scanner;

class Basic {
    private String nombre;
    private int dni;
    private double creditos;
    private int cantTitulos;

    public Basic(String nombre, int dni){
        this.nombre = nombre;
        this.dni = dni;
        this.creditos = 100;
        this.cantTitulos = 1;
    }

    public String getNombre(){
        return this.nombre;
    }
    public int getDNI(){
        return this.dni;
    }

    public void creditosCDGasto(){
        this.creditos = this.creditos - 40;
    }

    public void creditosLibroGasto(){
        this.creditos = this.creditos - 20;
    }
    
    public void creditosPeliGasto(){
        this.creditos = this.creditos - 60;
    }

    
    public void creditosCDRecupero(){
        this.creditos = this.creditos - 10;
    }
    public void creditosLibroRecupero(){
        this.creditos = this.creditos - 20;
    }
    public void creditosPeliRecupero(){
        this.creditos = this.creditos - 30;
    }
}

class Prefer {
    private String nombre;
    private int dni;
    private double creditos;
    private int cantTitulos;

    public Prefer(String nombre, int dni){
        this.nombre = nombre;
        this.dni = dni;
        this.creditos = 300;
        this.cantTitulos = 3;
    }
    public int getDNI(){
        return this.dni;
    }

    public String getNombre(){
        return this.nombre;
    }
    
    public void creditosCDGasto(){
        this.creditos = this.creditos - 40;
    }

    public void creditosLibroGasto(){
        this.creditos = this.creditos - 20;
    }
    
    public void creditosPeliGasto(){
        this.creditos = this.creditos - 60;
    }

    
    public void creditosCDRecupero(){
        this.creditos = this.creditos - 10;
    }
    public void creditosLibroRecupero(){
        this.creditos = this.creditos - 20;
    }
    public void creditosPeliRecupero(){
        this.creditos = this.creditos - 30;
    }
}

class Premium {
    private String nombre;
    private int dni;
    private double creditos;
    private int cantTitulos;

    public Premium(String nombre, int dni){
        this.nombre = nombre;
        this.dni = dni;
        this.creditos = 800;
        this.cantTitulos = 8;
    }

    public String getNombre(){
        return this.nombre;
    }

    public int getDNI(){
        return this.dni;
    }
    
    public void creditosCDGasto(){
        this.creditos = this.creditos - 40;
    }

    public void creditosLibroGasto(){
        this.creditos = this.creditos - 20;
    }
    
    public void creditosPeliGasto(){
        this.creditos = this.creditos - 60;
    }

    
    public void creditosCDRecupero(){
        this.creditos = this.creditos - 10;
    }
    public void creditosLibroRecupero(){
        this.creditos = this.creditos - 20;
    }
    public void creditosPeliRecupero(){
        this.creditos = this.creditos - 30;
    }
}

abstract class Item {
    
    // private String titulo;
    public abstract void setID(int res);
}

class CD extends Item{
    private String titulo;
    private String ID;
    private String interprete;
    private String sello;
    private int duracion;
    private double precio;
    private boolean estado;

    public CD(String t, String c, String a, int e){
        this.titulo = t;
        this.interprete = c;
        this.sello = a;
        this.duracion = e;
        this.precio = 40;
        this.estado = false;
    }

    public void setEstadoT(){
        this.estado = true;
    }

    public void setEstadoF(){
        this.estado = false;
    }

    public boolean getEstado(){
        return estado;
    }

    @Override
    public void setID(int res){
        this.ID = "CD" + Integer.toString(res);
    }

    public String getID(){
        return this.ID;
    }

    public String getT(){
        return this.titulo;
    }
}

class Libro extends Item{
    private String titulo;
    private String ID;
    private int ISBN;
    private String autor;
    private String editorial;
    private double precio;
    private boolean estado;

    public Libro(String t, int c, String a, String e){
        this.titulo = t;
        this.ISBN = c;
        this.autor = a;
        this.editorial = e;
        this.precio = 20;
        this.estado = false;
    }

    @Override
    public void setID(int res){
        this.ID = "Libro" + Integer.toString(res);
    }

    public String getID(){
        return this.ID;
    }

    public String getT(){
        return this.titulo;
    }

    public void setEstadoT(){
        this.estado = true;
    }

    public void setEstadoF(){
        this.estado = false;
    }

    public boolean getEstado(){
        return estado;
    }

}

class Pelicula extends Item{
    private String titulo;
    private String ID;
    private int duracion;
    private String sinopsis;
    private double precio;
    private boolean estado;

    public Pelicula(String t, int c, String a){
        this.titulo = t;
        this.duracion = c;
        this.sinopsis = a;
        this.precio = 60;
        this.estado = false;
    }

    
    @Override
    public void setID(int res){
        this.ID = "Peli" + Integer.toString(res);
    }

    public String getID(){
        return this.ID;
    }

    public String getT(){
        return this.titulo;
    }

    public void setEstadoT(){
        this.estado = true;
    }

    public void setEstadoF(){
        this.estado = false;
    }

    public boolean getEstado(){
        return estado;
    }
}


class Tienda {
    private ArrayList<CD> CDs;
    private ArrayList<Libro> libros;
    private ArrayList<Pelicula> pelis;
    private ArrayList<Basic> SBasic;
    private ArrayList<Prefer> SPrefer;
    private ArrayList<Premium> SPremium;

    public Tienda(){
        this.CDs = new ArrayList<>();
        this.libros = new ArrayList<>();
        this.pelis = new ArrayList<>();
        this.SBasic = new ArrayList<>();
        this.SPrefer = new ArrayList<>();
        this.SPremium = new ArrayList<>();
    }

    public void start(){
        System.out.println("Bienvenido a Blockbuster. Elija una de las siguientes opciones del menu: ");
        System.out.println("1. Alquiler\n2. Devolucion\n 3. Asociarse\n 4. Listados \n5. Nuevo inventario \n6. Salir");
        
        Scanner scanner = new Scanner(System.in);
        
        int sel = scanner.nextInt();
        scanner.nextLine();

        while (sel != 6){
            try {
                switch (sel){
                    case 1:
                        alquilar();
                        break;
                    case 2:
                        devolver();
                        break;
                    case 3:
                        nuevoUsuario();
                        break;
                    case 4:
                        listado();
                        break;
                    case 5:
                        nuevoInventario();
                        break;

                }

            } catch (Exception e){
                System.out.println("Hubo un error en la ejecucion!");
            }

            System.out.println("1. Alquiler\n2. Devolucion\n 3. Socios\n 4. Listados \n5. Nuevo inventario \n6. Salir");
            sel = scanner.nextInt();
            scanner.nextLine();
        }
    }

    public void alquilar(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese su tipo de asociatura: ");
        int socio = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Ingrese su usuario (dni): ");
        int dni = scanner.nextInt();
        scanner.nextLine();

        Basic sb;
        Prefer sp;
        Premium sp2;

        if (socio == 1){
            for (Basic b : SBasic){
                if (b.getDNI() ==  dni){
                    sb = b;
                    System.out.println("Que desea alquilar? ");
                    System.out.println("1. Libro\n2. CD\n 3. Pelicula\n 4. Salir");
                
                    int sel = scanner.nextInt();
                    scanner.nextLine();
                    try {
                        switch (sel){
                            case 1:
                                System.out.println("Ingrese codigo de CD (Puede ver en el listado): ");
                                String codigo = scanner.nextLine();
                                for (CD s : CDs){
                                    if (s.getEstado() == false && s.getID().contains(codigo)){
                                        s.setEstadoT();
                                        sb.creditosCDGasto();
                                        System.out.println("Usted ha alquilado " + s.getID());
                                        break;
                                    }
                                }
                                break;
                            case 2:
                                System.out.println("Ingrese codigo de libro (Puede ver en el listado): ");
                                String codigo2 = scanner.nextLine();
                                for (Libro s : libros){
                                    if (s.getEstado() == false && s.getID().contains(codigo2)){
                                        s.setEstadoT();
                                        sb.creditosLibroGasto();
                                        System.out.println("Usted ha alquilado " + s.getID());
                                        break;
                                    }
                                }
                                break;
                            case 3:
                                System.out.println("Ingrese codigo de pelicula (Puede ver en el listado): ");
                                String codigo3 = scanner.nextLine();
                                for (Pelicula s : pelis){
                                    if (s.getEstado() == false && s.getID().contains(codigo3)){
                                        s.setEstadoT();
                                        sb.creditosPeliGasto();
                                        System.out.println("Usted ha alquilado " + s.getID());
                                        break;
                                    }
                                }
                                break;
                            case 4:
                                //
                                break;
                        }
            
                    } catch (Exception e){
                        System.out.println("Hubo un error en la ejecucion!");
                    }
                }
            }
        if (socio == 2){
            for (Prefer p : SPrefer){
                if (p.getDNI() ==  dni){
                    sp = p;
                    System.out.println("Que desea alquilar? ");
                    System.out.println("1. Libro\n2. CD\n 3. Pelicula\n 4. Salir");
                    
                    int sel = scanner.nextInt();
                    scanner.nextLine();
                    try {
                        switch (sel){
                            case 1:
                                System.out.println("Ingrese codigo de CD (Puede ver en el listado): ");
                                String codigo = scanner.nextLine();
                                for (CD s : CDs){
                                    if (s.getEstado() == false && s.getID().contains(codigo)){
                                        s.setEstadoT();
                                        sp.creditosCDGasto();
                                        System.out.println("Usted ha alquilado " + s.getID());
                                        break;
                                    }
                                }
                                break;
                            case 2:
                                System.out.println("Ingrese codigo de libro (Puede ver en el listado): ");
                                String codigo2 = scanner.nextLine();
                                for (Libro s : libros){
                                    if (s.getEstado() == false && s.getID().contains(codigo2)){
                                        s.setEstadoT();
                                        sp.creditosLibroGasto();
                                        System.out.println("Usted ha alquilado " + s.getID());
                                        break;
                                    }
                                }
                                break;
                            case 3:
                                System.out.println("Ingrese codigo de pelicula (Puede ver en el listado): ");
                                String codigo3 = scanner.nextLine();
                                for (Pelicula s : pelis){
                                    if (s.getEstado() == false && s.getID().contains(codigo3)){
                                        s.setEstadoT();
                                        sp.creditosPeliGasto();
                                        System.out.println("Usted ha alquilado " + s.getID());
                                        break;
                                    }
                                }
                                break;
                            case 4:
                                //
                                break;
                        }
            
                    } catch (Exception e){
                        System.out.println("Hubo un error en la ejecucion!");
                    }
                }
            }
            }
        }
            

        
        if (socio == 3){
            for (Premium p2 : SPremium){
                if (p2.getDNI() ==  dni){

                    sp2 = p2;
                    System.out.println("Que desea alquilar? ");
                    System.out.println("1. Libro\n2. CD\n 3. Pelicula\n 4. Salir");
                    
                    int sel = scanner.nextInt();
                    scanner.nextLine();
                    try {
                        switch (sel){
                            case 1:
                                System.out.println("Ingrese codigo de CD (Puede ver en el listado): ");
                                String codigo = scanner.nextLine();
                                for (CD s : CDs){
                                    if (s.getEstado() == false && s.getID().contains(codigo)){
                                        s.setEstadoT();
                                        sp2.creditosCDGasto();
                                        System.out.println("Usted ha alquilado " + s.getID());
                                        break;
                                    }
                                }
                                break;
                            case 2:
                                System.out.println("Ingrese codigo de libro (Puede ver en el listado): ");
                                String codigo2 = scanner.nextLine();
                                for (Libro s : libros){
                                    if (s.getEstado() == false && s.getID().contains(codigo2)){
                                        s.setEstadoT();
                                        sp2.creditosLibroGasto();
                                        System.out.println("Usted ha alquilado " + s.getID());
                                        break;
                                    }
                                }
                                break;
                            case 3:
                                System.out.println("Ingrese codigo de pelicula (Puede ver en el listado): ");
                                String codigo3 = scanner.nextLine();
                                for (Pelicula s : pelis){
                                    if (s.getEstado() == false && s.getID().contains(codigo3)){
                                        s.setEstadoT();
                                        sp2.creditosPeliGasto();
                                        System.out.println("Usted ha alquilado " + s.getID());
                                        break;
                                    }
                                }
                                break;
                            case 4:
                                //
                                break;
                        }
            
                    } catch (Exception e){
                        System.out.println("Hubo un error en la ejecucion!");
                    }
                } else {
                    System.out.println("DNI incorrecto.");
                }
            }
        }
        
    }

    public void devolver(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese su tipo de asociatura: ");
        int socio = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Ingrese su usuario (dni): ");
        int dni = scanner.nextInt();
        scanner.nextLine();

        Basic sb;
        Prefer sp;
        Premium sp2;

        if (socio == 1){
            for (Basic b : SBasic){
                if (b.getDNI() ==  dni){
                    sb = b;
                    System.out.println("Que desea devolver? ");
                    System.out.println("1. Libro\n2. CD\n 3. Pelicula\n 4. Salir");
                
                    int sel = scanner.nextInt();
                    scanner.nextLine();
                    try {
                        switch (sel){
                            case 1:
                                System.out.println("Ingrese codigo de CD (Puede ver en el listado): ");
                                String codigo = scanner.nextLine();
                                for (CD s : CDs){
                                    if (s.getEstado() == true && s.getID().contains(codigo)){
                                        s.setEstadoF();
                                        sb.creditosCDRecupero();
                                        System.out.println("Usted ha devuelto " + s.getID());
                                        break;
                                    }
                                }
                                break;
                            case 2:
                                System.out.println("Ingrese codigo de libro (Puede ver en el listado): ");
                                String codigo2 = scanner.nextLine();
                                for (Libro s : libros){
                                    if (s.getEstado() == true && s.getID().contains(codigo2)){
                                        s.setEstadoF();
                                        sb.creditosLibroRecupero();
                                        System.out.println("Usted ha devuelto " + s.getID());
                                        break;
                                    }
                                }
                                break;
                            case 3:
                                System.out.println("Ingrese codigo de pelicula (Puede ver en el listado): ");
                                String codigo3 = scanner.nextLine();
                                for (Pelicula s : pelis){
                                    if (s.getEstado() == true && s.getID().contains(codigo3)){
                                        s.setEstadoF();
                                        sb.creditosPeliRecupero();
                                        System.out.println("Usted ha devuelto " + s.getID());
                                        break;
                                    }
                                }
                                break;
                            case 4:
                                //
                                break;
                        }
            
                    } catch (Exception e){
                        System.out.println("Hubo un error en la ejecucion!");
                    }
                }
            }
        if (socio == 2){
            for (Prefer p : SPrefer){
                if (p.getDNI() ==  dni){
                    sp = p;
                    System.out.println("Que desea alquilar? ");
                    System.out.println("1. Libro\n2. CD\n 3. Pelicula\n 4. Salir");
                    
                    int sel = scanner.nextInt();
                    scanner.nextLine();
                    try {
                        switch (sel){
                            case 1:
                                System.out.println("Ingrese codigo de CD (Puede ver en el listado): ");
                                String codigo = scanner.nextLine();
                                for (CD s : CDs){
                                    if (s.getEstado() == true && s.getID().contains(codigo)){
                                        s.setEstadoF();
                                        sp.creditosCDRecupero();
                                        System.out.println("Usted ha devuelto " + s.getID());
                                        break;
                                    }
                                }
                                break;
                            case 2:
                                System.out.println("Ingrese codigo de libro (Puede ver en el listado): ");
                                String codigo2 = scanner.nextLine();
                                for (Libro s : libros){
                                    if (s.getEstado() == true && s.getID().contains(codigo2)){
                                        s.setEstadoF();
                                        sp.creditosLibroRecupero();
                                        System.out.println("Usted ha devuelto " + s.getID());
                                        break;
                                    }
                                }
                                break;
                            case 3:
                                System.out.println("Ingrese codigo de pelicula (Puede ver en el listado): ");
                                String codigo3 = scanner.nextLine();
                                for (Pelicula s : pelis){
                                    if (s.getEstado() == true && s.getID().contains(codigo3)){
                                        s.setEstadoF();
                                        sp.creditosPeliRecupero();
                                        System.out.println("Usted ha devuelto " + s.getID());
                                        break;
                                    }
                                }
                                break;
                            case 4:
                                //
                                break;
                        }
            
                    } catch (Exception e){
                        System.out.println("Hubo un error en la ejecucion!");
                    }
                }
            }
            }
        }
            

        
        if (socio == 3){
            for (Premium p2 : SPremium){
                if (p2.getDNI() ==  dni){

                    sp2 = p2;
                    System.out.println("Que desea alquilar? ");
                    System.out.println("1. Libro\n2. CD\n 3. Pelicula\n 4. Salir");
                    
                    int sel = scanner.nextInt();
                    scanner.nextLine();
                    try {
                        switch (sel){
                            case 1:
                                System.out.println("Ingrese codigo de CD (Puede ver en el listado): ");
                                String codigo = scanner.nextLine();
                                for (CD s : CDs){
                                    if (s.getEstado() == true && s.getID().contains(codigo)){
                                        s.setEstadoF();
                                        sp2.creditosCDRecupero();
                                        System.out.println("Usted ha devuelto " + s.getID());
                                        break;
                                    }
                                }
                                break;
                            case 2:
                                System.out.println("Ingrese codigo de libro (Puede ver en el listado): ");
                                String codigo2 = scanner.nextLine();
                                for (Libro s : libros){
                                    if (s.getEstado() == true && s.getID().contains(codigo2)){
                                        s.setEstadoF();
                                        sp2.creditosLibroRecupero();
                                        System.out.println("Usted ha devuelto " + s.getID());
                                        break;
                                    }
                                }
                                break;
                            case 3:
                                System.out.println("Ingrese codigo de pelicula (Puede ver en el listado): ");
                                String codigo3 = scanner.nextLine();
                                for (Pelicula s : pelis){
                                    if (s.getEstado() == true && s.getID().contains(codigo3)){
                                        s.setEstadoF();
                                        sp2.creditosPeliRecupero();
                                        System.out.println("Usted ha devuelto " + s.getID());
                                        break;
                                    }
                                }
                                break;
                            case 4:
                                //
                                break;
                        }
            
                    } catch (Exception e){
                        System.out.println("Hubo un error en la ejecucion!");
                    }
                } else {
                    System.out.println("DNI incorrecto.");
                }
            }
        } 
    }


    public void nuevoInventario(){
        System.out.println("Que tipo de inventario desea agregar? ");
        System.out.println("1. Libro\n2. CD\n 3. Pelicula\n 4. Salir");
        Scanner scanner = new Scanner(System.in);
        
        int sel = scanner.nextInt();
        scanner.nextLine();
        try {
            switch (sel){
                case 1:
                    System.out.println("Ingrese nombre de libro: ");
                    String n = scanner.nextLine();
                    System.out.println("Ingrese autor de libro: ");
                    String i = scanner.nextLine();
                    System.out.println("Ingrese codigo ISBN de libro: ");
                    int d = scanner.nextInt();
                    scanner.nextLine();
                    System.out.println("Ingrese editorial de libro: ");
                    String e = scanner.nextLine();
                    Libro l = new Libro(n, d, i, e);
                    int numero = 1;
                    for (Libro c : libros){
                        numero ++;
                    }

                    l.setID(numero);
                    libros.add(l);
                    break;
                case 2:
                    System.out.println("Ingrese nombre de CD: ");
                    String n2 = scanner.nextLine();
                    System.out.println("Ingrese interprete de CD: ");
                    String i2 = scanner.nextLine();
                    System.out.println("Ingrese sello de CD: ");
                    String s = scanner.nextLine();
                    System.out.println("Ingrese duracion de CD: ");
                    int d2 = scanner.nextInt();
                    scanner.nextLine();
                    CD cd = new CD(n2, i2, s, d2);
                    int numero2 = 1;
                    for (CD c : CDs){
                        numero2 ++;
                    }

                    cd.setID(numero2);

                    CDs.add(cd);

                    break;
                case 3:
                    System.out.println("Ingrese nombre de pelicula: ");
                    String n3 = scanner.nextLine();
                    System.out.println("Ingrese duracion de pelicula: ");
                    int d3 = scanner.nextInt();
                    scanner.nextLine();
                    System.out.println("Ingrese sinopsis de pelicula: ");
                    String s3 = scanner.nextLine();

                    Pelicula p = new Pelicula(n3, d3, s3);
                    int numero3 = 1;
                    for (CD c : CDs){
                        numero3 ++;
                    }

                    p.setID(numero3);

                    pelis.add(p);
                    break;
                case 4:
                    //
                    break;
            }

        } catch (Exception e){
            System.out.println("Hubo un error en la ejecucion!");
        }
    }

    public void nuevoUsuario(){
        System.out.println("Que tipo de asociatura desea ? ");
        System.out.println("1. Basic\n2. Prefer\n 3. Premium\n 4. Salir");
        Scanner scanner = new Scanner(System.in);
        
        int sel = scanner.nextInt();
        scanner.nextLine();
        try {
            switch (sel){
                case 1:
                    System.out.println("Ingrese nombre de usuario: ");
                    String n = scanner.nextLine();
                    System.out.println("Ingrese dni de usuario: ");
                    int d = scanner.nextInt();
                    scanner.nextLine();

                    Basic b = new Basic(n, d);
                    SBasic.add(b);
                    break;
                case 2:
                    System.out.println("Ingrese nombre de usuario: ");
                    String n2 = scanner.nextLine();
                    System.out.println("Ingrese dni de usuario: ");
                    int d2 = scanner.nextInt();
                    scanner.nextLine();

                    Prefer p = new Prefer(n2, d2);
                    SPrefer.add(p);
                    break;
                case 3:
                    System.out.println("Ingrese nombre de usuario: ");
                    String n3 = scanner.nextLine();
                    System.out.println("Ingrese dni de usuario: ");
                    int d3 = scanner.nextInt();
                    scanner.nextLine();

                    Premium p2 = new Premium(n3, d3);
                    SPremium.add(p2);
                    break;
                case 4:
                    //
                    break;
            }

        } catch (Exception e){
            System.out.println("Hubo un error en la ejecucion!");
        }
    }

    public void listado(){
        System.out.println("Que tipo de listado desea ver? ");
        System.out.println("1. Socios\n2. Inventario\n 3. Salir");
        Scanner scanner = new Scanner(System.in);
        
        int sel = scanner.nextInt();
        scanner.nextLine();
        try {
            switch (sel){
                case 1:
                    int i = 1;
                    int j = 1;
                    int h = 1;
                    for (Basic s : SBasic){
                        System.out.println(s.getNombre() + " - Basic n" + i);
                        i++;
                    }
                    for (Prefer s : SPrefer){
                        System.out.println(s.getNombre() + " - Prefer n" + j);
                        i++;
                    }
                    for (Premium s : SPremium){
                        System.out.println(s.getNombre() + " - Premium n" + h);
                        i++;
                    }
                    break;
                case 2:
                    int q = 1;
                    int w = 1;
                    int e = 1;
                    for (Libro s : libros){
                        if (s.getEstado() == false){
                            System.out.println(s.getID() + " - " + s.getT() + " - Disponible");
                            q++;
                        } else {
                            
                            System.out.println(s.getID() + " - " + s.getT() + " - Alquilado");
                            q++;
                        }                        
                    }
                    for (CD s : CDs){
                        if (s.getEstado() == false){
                            System.out.println(s.getID() + " - " + s.getT() + " - Disponible");
                            w++;
                        } else {
                            
                            System.out.println(s.getID() + " - " + s.getT() + " - Alquilado");
                            w++;
                        }   
                    }
                    for (Pelicula s : pelis){
                        if (s.getEstado() == false){
                            System.out.println(s.getID() + " - " + s.getT() + " - Disponible");
                            e++;
                        } else {
                            
                            System.out.println(s.getID() + " - " + s.getT() + " - Alquilado");
                            e++;
                        }   
                    }

                    break;
                case 3:
                    //
                    break;
            }

        } catch (Exception e){
            System.out.println("Hubo un error en la ejecucion!");
        }
    }
}

class TiendaObj{
    public static void main(String[] args){
        Tienda t = new Tienda();

        t.start();

    }
}

// No llegue a reflejar en el codigo el limite de titulos por tipo de socio